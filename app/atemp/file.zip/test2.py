# from Crypto.Cipher import AES
# key = b'Sixteen byte key'
# cipher = AES.new(key, AES.MODE_EAX)
# nonce = cipher.nonce
# data = {
#     'ddfd':'df'
# }
# ciphertext, tag = cipher.encrypt_and_digest(data)
# print(ciphertext, tag)
# import json
 
# # create a sample json
 
# a = {"name" : "GeeksforGeeks", "Topic" : "Json to String", "Method": 1}
 
# # Convert JSON to String
# y = json.dumps(a)
 
# print(y)
# print(type(y))