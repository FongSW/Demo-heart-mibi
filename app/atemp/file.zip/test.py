

import requests



url = 'http://localhost:8001/predict_heart_api/predict_CAG'
files = {'img': open('iris-test-sentosa.jpg', 'rb')}
# sepal_lengths = 5.1
# sepal_width = 4.1
# petal_length = 1.5
# petal_width=0.1
# data = { 'sepal_length': sepal_lengths,
#          'sepal_width': sepal_width,
#          'petal_length': petal_length,
#          'petal_width': petal_width
#          }
#------------------------------------------------------------

patient_id = 1
S_MaxPerfusion = 1
S_Intervals = 1
S_ED = 1
S_ES = 1
S_EF = 1   
SM_LADPerfusion = 0.1
SSD_LADPerfusion = 0.1
SM_LCXPerfusion = 0.1
SSD_LCXPerfusion = 0.1
SM_RCAPerfusion = 0.1
SSD_RCAPerfusion = 0.1
SM_TOTPerfusion = 0.1
SSD_TOTPerfusion = 0.1
SM_LADWallThickening = 0.1
SSD_LADWallThickening = 0.1
SM_LCXWallThickening = 0.1
SSD_LCXWallThickening = 0.1
SM_RCAWallThickening = 0.1
SSD_RCAWallThickening = 0.1
SM_TOTWallThickening = 0.1
SSD_TOTWallThickening = 0.1
SM_LADWallMotion = 0.1
SSD_LADWallMotion = 0.1
SM_LCXWallMotion = 0.1
SSD_LCXWallMotion = 0.1
SM_RCAWallMotion = 0.1
SSD_RCAWallMotion = 0.1
SM_TOTWallMotion = 0.1
SSD_TOTWallMotion = 0.1       
SE_LADPerfusion = 1
SE_LCXPerfusion = 1
SE_RCAPerfusion = 1
SE_TOTPerfusion = 1
SE_LADWallThickening = 1
SE_LCXWallThickening = 1
SE_RCAWallThickening = 1
SE_TOTWallThickening = 1
SE_LADWallMotion = 1
SE_LCXWallMotion = 1
SE_RCAWallMotion = 1
SE_TOTWallMotion = 1
SSEV_LADPerfusion = 0.1
SSEV_LCXPerfusion = 0.1
SSEV_RCAPerfusion = 0.1
SSEV_TOTPerfusion = 0.1
SSEV_LADWallThickening = 0.1
SSEV_LCXWallThickening = 0.1
SSEV_RCAWallThickening = 0.1
SSEV_TOTWallThickening = 0.1
SSEV_LADWallMotion = 0.1
SSEV_LCXWallMotion = 0.1
SSEV_RCAWallMotion = 0.1
SSEV_TOTWallMotion = 0.1
R_MaxPerfusion = 1
R_Intervals = 1
R_ED = 1
R_ES = 1
R_EF = 1 
RM_LADPerfusion = 0.1
RSD_LADPerfusion = 0.1
RM_LCXPerfusion = 0.1
RSD_LCXPerfusion = 0.1
RM_RCAPerfusion = 0.1
RSD_RCAPerfusion = 0.1
RM_TOTPerfusion = 0.1
RSD_TOTPerfusion = 0.1
RM_LADWallThickening = 0.1
RSD_LADWallThickening = 0.1
RM_LCXWallThickening = 0.1
RSD_LCXWallThickening = 0.1
RM_RCAWallThickening = 0.1
RSD_RCAWallThickening = 0.1
RM_TOTWallThickening = 0.1
RSD_TOTWallThickening = 0.1
RM_LADWallMotion = 0.1
RSD_LADWallMotion = 0.1
RM_LCXWallMotion = 0.1
RSD_LCXWallMotion = 0.1
RM_RCAWallMotion = 0.1
RSD_RCAWallMotion = 0.1
RM_TOTWallMotion = 0.1
RSD_TOTWallMotion = 0.1  
RE_LADPerfusion = 1
RE_LCXPerfusion = 1
RE_RCAPerfusion = 1
RE_TOTPerfusion = 1
RE_LADWallThickening = 1
RE_LCXWallThickening = 1
RE_RCAWallThickening = 1
RE_TOTWallThickening = 1
RE_LADWallMotion = 1
RE_LCXWallMotion = 1
RE_RCAWallMotion = 1
RE_TOTWallMotion = 1
RSEV_LADPerfusion = 0.1
RSEV_LCXPerfusion = 0.1
RSEV_RCAPerfusion = 0.1
RSEV_TOTPerfusion = 0.1
RSEV_LADWallThickening = 0.1
RSEV_LCXWallThickening = 0.1
RSEV_RCAWallThickening = 0.1
RSEV_TOTWallThickening = 0.1
RSEV_LADWallMotion = 0.1
RSEV_LCXWallMotion = 0.1
RSEV_RCAWallMotion = 0.1
RSEV_TOTWallMotion = 0.1   
SSS = 1
S_STS = 1
S_SMS = 1
SRS = 1
R_STS = 1
R_SMS = 1
age = 1
gender = "M"
bmi = 0.1
dm = 1
ht = 1
dlp = 1
ckd = 1

data = {
    "patient_id": patient_id,
    "S_MaxPerfusion": S_MaxPerfusion,
    "S_Intervals": S_Intervals,
    "S_ED": S_ED,
    "S_ES": S_ES,
    "S_EF": S_EF,   
    "SM_LADPerfusion": SM_LADPerfusion,
    "SSD_LADPerfusion": SSD_LADPerfusion,
    "SM_LCXPerfusion": SM_LCXPerfusion,
    "SSD_LCXPerfusion": SSD_LCXPerfusion,
    "SM_RCAPerfusion": SM_RCAPerfusion,
    "SSD_RCAPerfusion": SSD_RCAPerfusion,
    "SM_TOTPerfusion": SM_TOTPerfusion,
    "SSD_TOTPerfusion": SSD_TOTPerfusion,
    "SM_LADWallThickening": SM_LADWallThickening,
    "SSD_LADWallThickening": SSD_LADWallThickening,
    "SM_LCXWallThickening": SM_LCXWallThickening,
    "SSD_LCXWallThickening": SSD_LCXWallThickening,
    "SM_RCAWallThickening": SM_RCAWallThickening,
    "SSD_RCAWallThickening": SSD_RCAWallThickening,
    "SM_TOTWallThickening": SM_TOTWallThickening,
    "SSD_TOTWallThickening": SSD_TOTWallThickening,
    "SM_LADWallMotion": SM_LADWallMotion,
    "SSD_LADWallMotion": SSD_LADWallMotion,
    "SM_LCXWallMotion": SM_LCXWallMotion,
    "SSD_LCXWallMotion": SSD_LCXWallMotion,
    "SM_RCAWallMotion": SM_RCAWallMotion,
    "SSD_RCAWallMotion": SSD_RCAWallMotion,
    "SM_TOTWallMotion": SM_TOTWallMotion,
    "SSD_TOTWallMotion": SSD_TOTWallMotion,     
    "SE_LADPerfusion": SE_LADPerfusion,
    "SE_LCXPerfusion": SE_LCXPerfusion,
    "SE_RCAPerfusion": SE_RCAPerfusion,
    "SE_TOTPerfusion": SE_TOTPerfusion,
    "SE_LADWallThickening": SE_LADWallThickening,
    "SE_LCXWallThickening": SE_LCXWallThickening,
    "SE_RCAWallThickening": SE_RCAWallThickening,
    "SE_TOTWallThickening": SE_TOTWallThickening,
    "SE_LADWallMotion": SE_LADWallMotion,
    "SE_LCXWallMotion": SE_LCXWallMotion,
    "SE_RCAWallMotion": SE_RCAWallMotion,
    "SE_TOTWallMotion": SE_TOTWallMotion,
    "SSEV_LADPerfusion": SSEV_LADPerfusion,
    "SSEV_LCXPerfusion": SSEV_LCXPerfusion,
    "SSEV_RCAPerfusion": SSEV_RCAPerfusion,
    "SSEV_TOTPerfusion": SSEV_TOTPerfusion,
    "SSEV_LADWallThickening": SSEV_LADWallThickening,
    "SSEV_LCXWallThickening": SSEV_LCXWallThickening,
    "SSEV_RCAWallThickening": SSEV_RCAWallThickening,
    "SSEV_TOTWallThickening": SSEV_TOTWallThickening,
    "SSEV_LADWallMotion": SSEV_LADWallMotion,
    "SSEV_LCXWallMotion": SSEV_LCXWallMotion,
    "SSEV_RCAWallMotion": SSEV_RCAWallMotion,
    "SSEV_TOTWallMotion": SSEV_TOTWallMotion,
    "R_MaxPerfusion": R_MaxPerfusion,
    "R_Intervals": R_Intervals,
    "R_ED": R_ED,
    "R_ES": R_ES,
    "R_EF": R_EF, 
    "RM_LADPerfusion": RM_LADPerfusion,
    "RSD_LADPerfusion": RSD_LADPerfusion,
    "RM_LCXPerfusion": RM_LCXPerfusion,
    "RSD_LCXPerfusion": RSD_LCXPerfusion,
    "RM_RCAPerfusion": RM_RCAPerfusion,
    "RSD_RCAPerfusion": RSD_RCAPerfusion,
    "RM_TOTPerfusion": RM_TOTPerfusion,
    "RSD_TOTPerfusion": RSD_TOTPerfusion,
    "RM_LADWallThickening": RM_LADWallThickening,
    "RSD_LADWallThickening": RSD_LADWallThickening,
    "RM_LCXWallThickening": RM_LCXWallThickening,
    "RSD_LCXWallThickening": RSD_LCXWallThickening,
    "RM_RCAWallThickening": RM_RCAWallThickening,
    "RSD_RCAWallThickening": RSD_RCAWallThickening,
    "RM_TOTWallThickening": RM_TOTWallThickening,
    "RSD_TOTWallThickening": RSD_TOTWallThickening,
    "RM_LADWallMotion": RM_LADWallMotion,
    "RSD_LADWallMotion": RSD_LADWallMotion,
    "RM_LCXWallMotion": RM_LCXWallMotion,
    "RSD_LCXWallMotion": RSD_LCXWallMotion,
    "RM_RCAWallMotion": RM_RCAWallMotion,
    "RSD_RCAWallMotion": RSD_RCAWallMotion,
    "RM_TOTWallMotion": RM_TOTWallMotion,
    "RSD_TOTWallMotion": RSD_TOTWallMotion,  
    "RE_LADPerfusion": RE_LADPerfusion,
    "RE_LCXPerfusion": RE_LCXPerfusion,
    "RE_RCAPerfusion": RE_RCAPerfusion,
    "RE_TOTPerfusion": RE_TOTPerfusion,
    "RE_LADWallThickening": RE_LADWallThickening,
    "RE_LCXWallThickening": RE_LCXWallThickening,
    "RE_RCAWallThickening": RE_RCAWallThickening,
    "RE_TOTWallThickening": RE_TOTWallThickening,
    "RE_LADWallMotion": RE_LADWallMotion,
    "RE_LCXWallMotion": RE_LCXWallMotion,
    "RE_RCAWallMotion": RE_RCAWallMotion,
    "RE_TOTWallMotion": RE_TOTWallMotion,
    "RSEV_LADPerfusion": RSEV_LADPerfusion,
    "RSEV_LCXPerfusion": RSEV_LCXPerfusion,
    "RSEV_RCAPerfusion": RSEV_RCAPerfusion,
    "RSEV_TOTPerfusion": RSEV_TOTPerfusion,
    "RSEV_LADWallThickening": RSEV_LADWallThickening,
    "RSEV_LCXWallThickening": RSEV_LCXWallThickening,
    "RSEV_RCAWallThickening": RSEV_RCAWallThickening,
    "RSEV_TOTWallThickening": RSEV_TOTWallThickening,
    "RSEV_LADWallMotion": RSEV_LADWallMotion,
    "RSEV_LCXWallMotion": RSEV_LCXWallMotion,
    "RSEV_RCAWallMotion": RSEV_RCAWallMotion,
    "RSEV_TOTWallMotion": RSEV_TOTWallMotion,   
    "SSS": SSS,
    "S_STS": S_STS,
    "S_SMS": S_SMS,
    "SRS": SRS,
    "R_STS": R_STS,
    "R_SMS": R_SMS,
    "age": age,
    "gender": gender,
    "bmi": bmi,
    "dm": dm,
    "ht": ht,
    "dlp": dlp,
    "ckd": ckd
}
#------------------------------------------------------------
# response = requests.post(url, data=data)
# response = requests.post(url, files=files, data=data)

# print("Status Code", response.status_code)
# print("JSON Response ", response.json())
# result = (response.json())['predict_label']
# print('result CAG:', result)

# data = {"patient_id": patient_id, "S_MaxPerfusion": S_MaxPerfusion, "S_Intervals": S_Intervals, "S_ED": S_ED, "S_ES": S_ES, "S_EF": S_EF,    "SM_LADPerfusion": SM_LADPerfusion, "SSD_LADPerfusion": SSD_LADPerfusion, "SM_LCXPerfusion": SM_LCXPerfusion, "SSD_LCXPerfusion": SSD_LCXPerfusion, "SM_RCAPerfusion": SM_RCAPerfusion, "SSD_RCAPerfusion": SSD_RCAPerfusion, "SM_TOTPerfusion": SM_TOTPerfusion, "SSD_TOTPerfusion": SSD_TOTPerfusion, "SM_LADWallThickening": SM_LADWallThickening, "SSD_LADWallThickening": SSD_LADWallThickening, "SM_LCXWallThickening": SM_LCXWallThickening, "SSD_LCXWallThickening": SSD_LCXWallThickening, "SM_RCAWallThickening": SM_RCAWallThickening, "SSD_RCAWallThickening": SSD_RCAWallThickening, "SM_TOTWallThickening": SM_TOTWallThickening, "SSD_TOTWallThickening": SSD_TOTWallThickening, "SM_LADWallMotion": SM_LADWallMotion, "SSD_LADWallMotion": SSD_LADWallMotion, "SM_LCXWallMotion": SM_LCXWallMotion, "SSD_LCXWallMotion": SSD_LCXWallMotion, "SM_RCAWallMotion": SM_RCAWallMotion, "SSD_RCAWallMotion": SSD_RCAWallMotion, "SM_TOTWallMotion": SM_TOTWallMotion, "SSD_TOTWallMotion": SSD_TOTWallMotion,      "SE_LADPerfusion": SE_LADPerfusion, "SE_LCXPerfusion": SE_LCXPerfusion, "SE_RCAPerfusion": SE_RCAPerfusion, "SE_TOTPerfusion": SE_TOTPerfusion, "SE_LADWallThickening": SE_LADWallThickening, "SE_LCXWallThickening": SE_LCXWallThickening, "SE_RCAWallThickening": SE_RCAWallThickening, "SE_TOTWallThickening": SE_TOTWallThickening, "SE_LADWallMotion": SE_LADWallMotion, "SE_LCXWallMotion": SE_LCXWallMotion, "SE_RCAWallMotion": SE_RCAWallMotion, "SE_TOTWallMotion": SE_TOTWallMotion, "SSEV_LADPerfusion": SSEV_LADPerfusion, "SSEV_LCXPerfusion": SSEV_LCXPerfusion, "SSEV_RCAPerfusion": SSEV_RCAPerfusion, "SSEV_TOTPerfusion": SSEV_TOTPerfusion, "SSEV_LADWallThickening": SSEV_LADWallThickening, "SSEV_LCXWallThickening": SSEV_LCXWallThickening, "SSEV_RCAWallThickening": SSEV_RCAWallThickening, "SSEV_TOTWallThickening": SSEV_TOTWallThickening, "SSEV_LADWallMotion": SSEV_LADWallMotion, "SSEV_LCXWallMotion": SSEV_LCXWallMotion, "SSEV_RCAWallMotion": SSEV_RCAWallMotion, "SSEV_TOTWallMotion": SSEV_TOTWallMotion, "R_MaxPerfusion": R_MaxPerfusion, "R_Intervals": R_Intervals, "R_ED": R_ED, "R_ES": R_ES, "R_EF": R_EF,  "RM_LADPerfusion": RM_LADPerfusion, "RSD_LADPerfusion": RSD_LADPerfusion, "RM_LCXPerfusion": RM_LCXPerfusion, "RSD_LCXPerfusion": RSD_LCXPerfusion, "RM_RCAPerfusion": RM_RCAPerfusion, "RSD_RCAPerfusion": RSD_RCAPerfusion, "RM_TOTPerfusion": RM_TOTPerfusion, "RSD_TOTPerfusion": RSD_TOTPerfusion, "RM_LADWallThickening": RM_LADWallThickening, "RSD_LADWallThickening": RSD_LADWallThickening, "RM_LCXWallThickening": RM_LCXWallThickening, "RSD_LCXWallThickening": RSD_LCXWallThickening, "RM_RCAWallThickening": RM_RCAWallThickening, "RSD_RCAWallThickening": RSD_RCAWallThickening, "RM_TOTWallThickening": RM_TOTWallThickening, "RSD_TOTWallThickening": RSD_TOTWallThickening, "RM_LADWallMotion": RM_LADWallMotion, "RSD_LADWallMotion": RSD_LADWallMotion, "RM_LCXWallMotion": RM_LCXWallMotion, "RSD_LCXWallMotion": RSD_LCXWallMotion, "RM_RCAWallMotion": RM_RCAWallMotion, "RSD_RCAWallMotion": RSD_RCAWallMotion, "RM_TOTWallMotion": RM_TOTWallMotion, "RSD_TOTWallMotion": RSD_TOTWallMotion,   "RE_LADPerfusion": RE_LADPerfusion, "RE_LCXPerfusion": RE_LCXPerfusion, "RE_RCAPerfusion": RE_RCAPerfusion, "RE_TOTPerfusion": RE_TOTPerfusion, "RE_LADWallThickening": RE_LADWallThickening, "RE_LCXWallThickening": RE_LCXWallThickening, "RE_RCAWallThickening": RE_RCAWallThickening, "RE_TOTWallThickening": RE_TOTWallThickening, "RE_LADWallMotion": RE_LADWallMotion, "RE_LCXWallMotion": RE_LCXWallMotion, "RE_RCAWallMotion": RE_RCAWallMotion, "RE_TOTWallMotion": RE_TOTWallMotion, "RSEV_LADPerfusion": RSEV_LADPerfusion, "RSEV_LCXPerfusion": RSEV_LCXPerfusion, "RSEV_RCAPerfusion": RSEV_RCAPerfusion, "RSEV_TOTPerfusion": RSEV_TOTPerfusion, "RSEV_LADWallThickening": RSEV_LADWallThickening, "RSEV_LCXWallThickening": RSEV_LCXWallThickening, "RSEV_RCAWallThickening": RSEV_RCAWallThickening, "RSEV_TOTWallThickening": RSEV_TOTWallThickening, "RSEV_LADWallMotion": RSEV_LADWallMotion, "RSEV_LCXWallMotion": RSEV_LCXWallMotion, "RSEV_RCAWallMotion": RSEV_RCAWallMotion, "RSEV_TOTWallMotion": RSEV_TOTWallMotion,    "SSS": SSS, "S_STS": S_STS, "S_SMS": S_SMS, "SRS": SRS, "R_STS": R_STS, "R_SMS": R_SMS, "age": age, "gender": gender, "bmi": bmi, "dm": dm, "ht": ht, "dlp": dlp, "ckd": ckd }


# URL_2 = "http://localhost:8001/predict_heart_api/info_model2"
# response =requests.get(url = URL_2, headers={'Authorization': 'Bearer {}'.format(myToken)})
# print("Status Code", response.status_code)
# print("JSON Response ", response.json())
# result = response.json()
# param = result['parameter']
# acc = result['accuracy_model']
# date_update = result['date_create']
# print(acc, param, date_update)
# result = (response.json())['predict_label']


# print('result  ', result)


#test 
# >>> import requests
# generate token
URL_1 = "http://localhost:8001/predict_heart_api/user/get_token_by_password"
data = {
    "email": "fongzxzxzx@gmail.com",
    "password": "123456"
}
response = requests.post(URL_1, json = data)
print('***generate token******')
print("Status Code", response.status_code)
print("Toker Response", response.json())
myToken = response.json()['access_token']
# verify token
URL_2 = "http://localhost:8001/predict_heart_api/info_model2"
response =requests.get(url = URL_2, headers={'Authorization': 'Bearer {}'.format(myToken)})
print('*****verify token******')
print("Status Code", response.status_code)
print("JSON Response ", response.json())
